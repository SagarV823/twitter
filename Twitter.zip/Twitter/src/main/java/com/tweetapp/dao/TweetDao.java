package com.tweetapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.tweetapp.db.ConnectionManager;

public class TweetDao {

	public void postNewTweet(String currentuseremail, String tweet) {
		Connection con = ConnectionManager.getConnection();
		String query = "insert into Tweets (email, tweet)" + " values (?, ?)";
		try {
			PreparedStatement preparedStmt = con.prepareStatement(query);
			preparedStmt.setString(1, currentuseremail);
			preparedStmt.setString(2, tweet);
			preparedStmt.execute();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public List<String> viewMyTweets(String currentuseremail) {
		List<String> ar1 = new ArrayList<String>();
		Connection con = ConnectionManager.getConnection();
		String query = "SELECT tweet FROM tweets WHERE email = '" + currentuseremail + "'";
		try {
			Statement statement = con.createStatement();
			ResultSet resultSet = statement.executeQuery(query);
			while (resultSet.next()) {
				ar1.add(resultSet.getString("tweet"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ar1;
	}

	public List<String> viewAllTweets() {
		List<String> ar1 = new ArrayList<String>();
		Connection con = ConnectionManager.getConnection();
		String query = "SELECT tweets.tweet,users.username FROM tweets INNER JOIN users on tweets.email = users.email";
		try {
			Statement statement = con.createStatement();
			ResultSet resultSet = statement.executeQuery(query);
			while (resultSet.next()) {
				ar1.add(resultSet.getString("tweet")+" - "+resultSet.getString("email"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ar1;
	}

}
