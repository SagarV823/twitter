package com.tweetapp.service;

import java.util.ArrayList;
import java.util.List;

import com.tweetapp.dao.*;

public class UserService {

	UserDao userDao=new UserDao();
	TweetDao tweetDao=new TweetDao();
	
	public void registerUser(String username,String email,String password, String answer){
		userDao.registerUser(username, email, password,answer);
	}

	public String LoginUser(String email, String password) {
		return userDao.LoginUser(email, password);
	}

	public boolean forgotPassword(String email, String answer) {
		return userDao.forgotPassword(email,answer);
	}
	
	public void changePassword(String email,String newPassword){
		userDao.changePassword(email,newPassword);
	}

	public void resetPassword(String oldPassword, String newPassword, String currentuserEmail) {
		userDao.resetPassword(oldPassword,newPassword,currentuserEmail);
	}

	public List<String> viewAllUsers() {
		return userDao.viewAllUsers();
	}
	
}
